# Venom-Tools-Installer
<b>Introduction</b><br>
Venom-Tool-Installer is a Kali Linux hacking tools installer for Termux and linux system. Venom-Tool-Installer was developed for Termux and linux based systems. Using Venom-Tool-Installer, you can install almost 370+ hacking tools in Termux (android) and other Linux based distributions. Now Venom-Tool-Installer is available for Ubuntu, Debian etc.

<b>Operating System Requirements</b><br>
Tool-X works on any of the following operating systems:<br>
• Android (Using the Termux App)<br>
• Linux (Debian Based Systems)<br>
• Unix<br>
